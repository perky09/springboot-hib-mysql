import { Injectable } from '@angular/core';
import {Http,Response,Headers,RequestOptions} from '@angular/http';
import {Observable} from 'rxjs';
import { map } from 'rxjs/operators';

import {User} from '../user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseUrl: string='http://localhost:8080/api';
  private headers=new Headers({'Content-Type':'application/json'});
  private options=new RequestOptions({headers:this.headers});
  constructor(private _http:Http) { }
  getData(){
  return this._http.get(this.baseUrl +'/users',this.options).pipe(map((response:Response)=>response.json()));
  
  }
  
 
}
