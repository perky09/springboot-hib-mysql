package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.UserDao;
import com.example.demo.service.DBService;

@Service
public class DBServiceImpl implements DBService {
	
	@Autowired
	private UserDao userDao;

	@Override
	public List getUserDetails() {
		
		return userDao.getUserDetails();
	}

}
