package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.UserDetails;
import com.example.demo.service.DBService;



@RestController
@RequestMapping(value="/api",method=RequestMethod.GET)
@CrossOrigin(origins="http://localhost:4200",allowedHeaders="*")
public class RestAPIController {
	
	@Autowired
	private DBService dbservice;
	
	//@RequestMapping(value ="/fetchDetails",method = RequestMethod.GET)
	@GetMapping("/users")
	public ResponseEntity<List<UserDetails>> getData() {
		List<UserDetails> userData = dbservice.getUserDetails();
		return new ResponseEntity<List<UserDetails>>(userData/*body of response*/, HttpStatus.OK);
	}
	
	

}
